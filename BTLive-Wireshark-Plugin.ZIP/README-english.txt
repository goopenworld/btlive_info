README
======

One strength of the Wireshark network protocol analyzer is that it can be extended to analyze arbitrary protocols by writing custom dissectors. The btlive plugin adds recognition and dissection of BitTorrent Live packets to Wireshark. If installed, the different BitTorrent Live packet types can be recognised and even contents of certain fields, which represent specific variables, can be identified (for example the number of the club, to which a peer belongs to). 

Please take the following steps to install the wireshark plugins contained in this folder:

1. choose the plugin which was compiled for your operating system (f.e. btlive-Ubuntu-32bit.so)
2. rename the plugin to btlive.so
3. copy the plugin to ~/.wireshark/plugins
4. restart wireshark



