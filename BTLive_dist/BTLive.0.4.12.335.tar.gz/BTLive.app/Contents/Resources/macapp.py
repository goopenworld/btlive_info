from core.liveapp import LiveApp
import signal

try:
    import sitecustomize
except:
    pass


class MacApp(LiveApp):
    def build_args(self):
        self.argparser.add_argument('--ui-pid', action='store', type=int, dest='ui_pid',
                                    help="Pass the PID of the enclosing Mac UI.")
        LiveApp.build_args(self)  # Add the cross platform args

    def parse_args(self):
        LiveApp.parse_args(self)
        if self.args.ui_pid:
            self.live_preferences.ui_pid = self.args.ui_pid
        else:
            self.live_preferences.dau_thread_enabled = False

    def launch_ui(self):
        if self.live_preferences.ui_pid:
            self.monitor_ui_pid(self.live_preferences.ui_pid, self.exit_app, 3)
        self.set_signals()
        signal.pause()

if __name__ == "__main__":
    app = MacApp()
    app.run_app()
