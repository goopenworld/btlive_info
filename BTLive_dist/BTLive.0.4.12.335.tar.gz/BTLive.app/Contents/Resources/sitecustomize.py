"""
For some reason, easy_install.pth in the site-packages directory causes the site-packages version of any egg
to be preferred over the one we ship with the mac app. This code removes the system site-packages from sys.path,
so that we don't end up with egg collisions on the mac.
"""

import sys
from distutils.sysconfig import get_python_lib

site_packages_location = get_python_lib()

sys.path = [path_item for path_item in sys.path if not path_item.startswith(site_packages_location)]
