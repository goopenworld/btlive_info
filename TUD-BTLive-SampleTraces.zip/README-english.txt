README
======

One strength of the Wireshark network protocol analyzer is that it can be extended to analyze arbitrary protocols by writing custom dissectors. The btlive plugin adds recognition and dissection of BitTorrent Live packets to Wireshark. If installed, the different BitTorrent Live packet types can be recognised and even contents of certain fields, which represent specific variables, can be identified (for example the number of the club, to which a peer belongs to). 

Please take the following steps to install the wireshark plugins:

1. choose the plugin which was compiled for your operating system (f.e. btlive-Ubuntu-32bit.so)
2. rename the plugin to btlive.so
3. copy the plugin to ~/.wireshark/plugins
4. restart wireshark


======== TESTING THE PLUGIN: PCAP FILES ==========

The plugin can be tested with the pcap files that can be found in the "btlive-sessions" folder. The .pcap files contain packets which belong to BitTorrent Live Client sessions using client version 0.4.12.335. 

In both sessions, we first started the source and subsequently added 10 peers to the swarm, with an offset of 2 seconds in-between. The .pcap files were captured on the last peer that joined the swarm. The peers were running on emanicslab servers (http://www.emanicslab.org) on 10 different sites across europe. The clients used the streaming media client rtmpdump. The resulting videos were saved to disk and are also contained in the "btlive-sessions" folder. By using "timeout 5m", the rtmpdump command was terminated after exactly 5 minutes (if it hadn't already stopped before). The capture length for each packet was limited to 200 bytes.

In both sessions, the peers requested the channel "tudps", which we setup by using our broadcasting account. The ip of the source was 130.83.245.123.The channel "tudps" was streaming the video big buck bunny, which is available from http://www.bigbuckbunny.org. It is part of the Peach open movie project and is licensed under the Creative Commons Attribution 3.0 license. We used the big_buck_bunny_480p_h264.mov and converted it with avconv to fit the medium quality recommended by BitTorrent:
outformat=flv
outframerate=25 
outresolution=640x360 
outvideorate=500k 
outaudiorate=96k 


capture-150.254.185.238Client0-btlive.pcap.gz:
The upload and also the download bandwidth of the source was limited with tc to 2600kbits per second in each case. The bandwiths of the peers were unlimited. The client did not leave the swarm until it was being killed. Because it was killed, there is no unsubscribe message contained in the capture. To see the unsubscribe procedure, please take a look at the .pcap file below.
local ip:      150.254.185.238, port 31400 (peer ip and port of the peer on which the .pcap file was captured)
tracker ip:    54.205.249.248, port 3000
source ip:     130.83.245.123, port 31400
First packet:  2014-02-27 16:08:17
Last packet:   2014-02-27 16:13:32
Elapsed:       00:04:14
Packets:       312571
Bytes:         68,018,209
Avg. MBit/sec: 1.728


capture-137.193.69.225Client0-btlive.pcap.gz
The upload and also the download bandwidth of the source and the peers was limited with tc to 700 kbits per second in each case. That means the source did provide less bandwidth than recommended by BitTorrent. According to our measurements, 700 kbits are the approximate amount of bandwidth a source needs to have if there is exactly one peer in the swarm. The peer, to which this .pcap file belongs, already left the swarm (unsubscribe) 01:29 minutes after subscribing. Only a few seconds of video were retrieved, and they also are of poor quality.
local ip:      137.193.69.225, port 31400 (peer ip and port of the peer on which the .pcap file was captured)
tracker ip:    54.205.249.248, port 3000
source ip:     130.83.245.123, port 31400
First packet:  2014-03-13 14:31:19
Last packet:   2014-03-13 14:33:02
Elapsed:       00:01:42
Packets:       33941
Bytes:         11,124,217
Avg. MBit/sec: 0.864



